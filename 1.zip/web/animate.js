async function loadJson(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Failed to load ${path}: ${res.status}`);
  return res.json();
}

function baseName(path) {
  if (!path) return path;
  const parts = path.split(/[\\/]/);
  return parts[parts.length - 1];
}

function assetPath(fileData) {
  if (!fileData) return null;
  if (fileData.Type === "PlistSubImage") {
    return `assets/${fileData.Path}`;
  }
  if (fileData.Type === "Normal") {
    return `assets/${baseName(fileData.Path)}`;
  }
  return null;
}

function createElementForNode(node) {
  const el = document.createElement("div");
  el.classList.add("node");
  const size = node.Size || { X: 0, Y: 0 };
  el.style.width = `${size.X}px`;
  el.style.height = `${size.Y}px`;
  el.__size = { w: size.X || 0, h: size.Y || 0 };

  const blend = node.BlendFunc || {};
  if (blend.Src === 770 && blend.Dst === 1) {
    el.style.mixBlendMode = "screen"; // additive
  }

  if (node.ctype === "SpriteObjectData" || node.ctype === "SingleNodeObjectData") {
    const src = assetPath(node.FileData);
    if (src) {
      el.style.backgroundImage = `url(${src})`;
      el.style.backgroundSize = "100% 100%";
      el.style.backgroundRepeat = "no-repeat";
    }
  } else if (node.ctype === "TextObjectData") {
    el.textContent = node.LabelText || "";
    el.classList.add("text-node");
    el.style.fontSize = `${node.FontSize || 24}px`;
    el.style.color = `rgb(${node.CColor?.R || 255},${node.CColor?.G || 255},${node.CColor?.B || 255})`;
    el.style.textAlign = "center";
    el.style.whiteSpace = "nowrap";
  }

  el.dataset.actionTag = node.ActionTag;
  el.dataset.name = node.Name || "";
  el.dataset.ctype = node.ctype;
  return el;
}

function normalizeAnchor(anchor) {
  if (!anchor) return [0.5, 0.5];
  const ax = Object.prototype.hasOwnProperty.call(anchor, "ScaleX") ? anchor.ScaleX : 0;
  const ay = Object.prototype.hasOwnProperty.call(anchor, "ScaleY") ? anchor.ScaleY : 0;
  return [ax, ay];
}

function applyTransform(el, state) {
  const [ax, ay] = normalizeAnchor(state.AnchorPoint);
  const x = state.Position?.X || 0;
  let y = state.Position?.Y || 0;
  const sx = state.Scale?.X ?? 1;
  const sy = state.Scale?.Y ?? 1;
  const rot = state.RotationSkewX ?? 0;
  // Manual tweaks: title stays where it is, display a bit lower.
  // if (el.dataset.name && el.dataset.name.startsWith("title_")) {
  //   const syEff = sy || 1;
  //   y -= 250 / syEff;
  // }
  // if (el.dataset.name === "display_bg") {
  //   const syEff = sy || 1;
  //   y -= 170 / syEff;
  // }

  // Position the element so that its anchor lies at (x, y) in the root space (y-down like Cocos Studio).
  el.style.left = `${x}px`;
  el.style.top = `${-y}px`;
  el.style.transformOrigin = `${ax * 100}% ${ay * 100}%`;
  el.style.transform = `translate(${-ax * 100}%, ${-ay * 100}%) scale(${sx}, ${sy}) rotate(${rot}deg)`;
  if (typeof state.Alpha === "number") {
    el.style.opacity = state.Alpha / 255;
  }
  if (typeof state.VisibleForFrame === "boolean") {
    el.style.visibility = state.VisibleForFrame ? "visible" : "hidden";
  }
}

function buildTimelineMap(animation) {
  const map = new Map();
  for (const timeline of animation.Timelines || []) {
    const tag = timeline.ActionTag;
    if (!map.has(tag)) map.set(tag, new Map());
    const propMap = map.get(tag);
    propMap.set(timeline.Property, timeline.Frames || timeline.Frame || []);
  }
  return map;
}

function sampleFrame(frames, frameIndex) {
  if (!frames || frames.length === 0) return undefined;
  if (frameIndex <= frames[0].FrameIndex) return frames[0];
  if (frameIndex >= frames[frames.length - 1].FrameIndex) return frames[frames.length - 1];
  for (let i = 0; i < frames.length - 1; i++) {
    const a = frames[i];
    const b = frames[i + 1];
    if (frameIndex >= a.FrameIndex && frameIndex <= b.FrameIndex) {
      const t = (frameIndex - a.FrameIndex) / (b.FrameIndex - a.FrameIndex || 1);
      if (a.ctype === "PointFrameData") {
        return { X: a.X + (b.X - a.X) * t, Y: a.Y + (b.Y - a.Y) * t };
      }
      if (a.ctype === "ScaleValueFrameData") {
        return { X: a.X + (b.X - a.X) * t, Y: a.Y + (b.Y - a.Y) * t };
      }
      if (a.ctype === "IntFrameData") {
        return { Value: a.Value + (b.Value - a.Value) * t };
      }
      if (a.ctype === "BoolFrameData") {
        return { Value: t < 1 ? a.Value : b.Value };
      }
      if (a.ctype === "TextureFrameData") {
        return t < 1 ? a : b;
      }
      return a;
    }
  }
  return frames[frames.length - 1];
}

function extractInitialState(node) {
  return {
    Position: node.Position || { X: 0, Y: 0 },
    Scale: node.Scale || { X: 1, Y: 1 },
    RotationSkewX: node.RotationSkewX || 0,
    RotationSkewY: node.RotationSkewY || 0,
    AnchorPoint: node.AnchorPoint || { ScaleX: 0.5, ScaleY: 0.5 },
    Alpha: typeof node.Alpha === "number" ? node.Alpha : 255,
    VisibleForFrame: node.VisibleForFrame !== false,
    FileData: node.FileData,
    BlendFunc: node.BlendFunc,
  };
}

function updateProperty(state, property, sample) {
  if (!sample) return;
  if (property === "Position") state.Position = sample;
  if (property === "Scale") state.Scale = sample;
  if (property === "RotationSkew") state.RotationSkewX = sample.X;
  if (property === "Alpha") state.Alpha = sample.Value;
  if (property === "VisibleForFrame") state.VisibleForFrame = sample.Value;
  if (property === "FileData" && sample.TextureFile) state.FileData = sample.TextureFile;
  if (property === "BlendFunc") state.BlendFunc = sample;
}

async function buildNodes(node, parentEl, actionMap, assetsBase = "assets", zIndex = 0) {
  const el = createElementForNode(node);
  const state = extractInitialState(node);
  el.__baseState = state;
  el.classList.add("sprite");
  el.style.zIndex = String(zIndex);
  parentEl.appendChild(el);
  const tag = node.ActionTag;
  if (!actionMap.has(tag)) actionMap.set(tag, []);
  actionMap.get(tag).push(el);

  if (node.Children) {
    for (let idx = 0; idx < node.Children.length; idx++) {
      const child = node.Children[idx];
      if (child.ctype === "ProjectNodeObjectData" && child.FileData?.Path) {
        const nested = await loadJson(`../res/exportJosn/${child.FileData.Path}`);
        const nestedObj = nested.Content.Content.ObjectData;
        if (child.Name) {
          nestedObj.Name = child.Name;
        }
        nestedObj.Position = child.Position;
        nestedObj.Scale = child.Scale;
        nestedObj.AnchorPoint = child.AnchorPoint;
        nestedObj.ActionTag = child.ActionTag;
        nestedObj.Alpha = child.Alpha;
        await buildNodes(nestedObj, el, actionMap, assetsBase, zIndex + idx + 1);
      } else {
        await buildNodes(child, el, actionMap, assetsBase, zIndex + idx + 1);
      }
    }
  }
}

async function main() {
  const root = document.querySelector("#scene-origin");
  const stage = document.querySelector("#stage");
  if (!root || !stage) return;

  const data = await loadJson("../res/exportJosn/jackpot.json");
  const animation = data.Content.Content.Animation;
  const objectData = data.Content.Content.ObjectData;
  const timelines = buildTimelineMap(animation);

  const actionMap = new Map();
  await buildNodes(objectData, root, actionMap);

  const durationFrames = animation.Duration;
  const fps = 60;
  const totalMs = (durationFrames / fps) * 1000;
  let start = performance.now();

  const resize = () => {
    const rect = stage.getBoundingClientRect();
    const scaleX = rect.width / 1280;
    const scaleY = rect.height / 720;
    const scale = Math.min(scaleX, scaleY);
    root.style.setProperty("--scene-scale", scale.toString());
  };
  resize();
  window.addEventListener("resize", resize);

  function tick(now) {
    const elapsed = (now - start) % totalMs;
    const frame = (elapsed / totalMs) * durationFrames;

    for (const [tag, elements] of actionMap.entries()) {
      const propMap = timelines.get(tag) || new Map();
      for (const el of elements) {
        const state = { ...el.__baseState };
        for (const [prop, frames] of propMap.entries()) {
          const val = sampleFrame(frames, frame);
          updateProperty(state, prop, val);
        }
        // Handle texture change
        const tex = state.FileData;
        if (tex && tex.Path) {
          const name = baseName(tex.Path);
          if (name) {
            el.style.backgroundImage = `url(assets/${name})`;
          }
        }
        // BlendFunc at runtime (in case it changes, though rare)
        const blend = state.BlendFunc || el.__baseState?.BlendFunc;
        if (blend && blend.Src === 770 && blend.Dst === 1) {
          el.style.mixBlendMode = "screen";
        }
        applyTransform(el, state);
      }
    }

    requestAnimationFrame(tick);
  }

  requestAnimationFrame(tick);
}

document.addEventListener("DOMContentLoaded", () => {
  main().catch((err) => console.error(err));
});
